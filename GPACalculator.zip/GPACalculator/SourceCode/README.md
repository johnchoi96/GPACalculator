# GPACalculator

Terminal based GPA Calculator application.
GPA points based on The Ohio State University, Columbus, OH.

 OS | Instruction
--- | ---
Windows | Run `GPACalculator.exe`
UNIX | Issue `make` command to compile and issue `./gpa` to run.

Download at [John Choi - Workspace](https://johnchoi96.github.io/downloads.html)
