Windows User: Run GPACalculator.exe located in Windows folder.

macOS User: Double click on GPACalculator located in macOS folder.

Linux User: Open terminal, navigate to the SourceCode folder, and execute
	"make clean;make" command and run the executable with "./gpa" command.


